export enum SensorStatus{
    Active ="Active",
    Inactive ="Inactive",
    Faulty = "Faulty"
}