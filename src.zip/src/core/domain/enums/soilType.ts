export enum SoilType{
  Sand = "Sand",
  LoamySand = "LoamySand",
  SandyLoam = "SandyLoam",
  Loam = "Loam",
  SiltLoam = "SiltLoam",
  ClayLoam = "ClayLoam",
  Clay = "Clay",
  Peaty = "Peaty",
  Chalky = "Chalky"
}