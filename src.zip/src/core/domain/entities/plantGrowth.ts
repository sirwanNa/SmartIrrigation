import {BaseEntity} from './baseEntity'
export interface plantGrowth extends BaseEntity{
   fieldId:number;
   size:number;
}