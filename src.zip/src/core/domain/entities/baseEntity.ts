
export interface BaseEntity{
    Id:number;
    CreatedDate:Date;
}