import {BaseModel} from './baseModel'
export interface PlantGrowthDTO extends BaseModel {
   fieldId:number;
   size:number;
}