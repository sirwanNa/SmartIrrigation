export interface BaseModel{
    id:number;
    createdDate:Date;
}